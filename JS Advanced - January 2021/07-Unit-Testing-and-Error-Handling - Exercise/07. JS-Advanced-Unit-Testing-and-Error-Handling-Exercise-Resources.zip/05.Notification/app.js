function notify(message) {
    // TODO:
  }