import unittest

from project.hardware.hardware import Hardware
from project.software.express_software import ExpressSoftware
from project.software.software import Software


class TestPaintFactory(unittest.TestCase):
    def setUp(self) -> None:
#        def __init__(self, name: str, type: str, capacity: int, memory: int):

        self.heavy_h = Hardware('HH', 'Heavy', 2000, 500)
        self.power_h = Hardware('ZZ', 'Power', 200, 5000)

    def test_setted_param(self):
        self.assertEqual(self.heavy_h.name, 'HH')
        self.assertEqual(self.power_h.name, 'ZZ')
        self.assertEqual(self.heavy_h.capacity, 2000)
        self.assertEqual(self.power_h.capacity, 200)
        self.assertEqual(self.heavy_h.memory, 500)
        self.assertEqual(self.power_h.memory, 5000)
        self.assertEqual(self.heavy_h.__class__.__name__, 'Hardware')
        self.assertEqual(self.power_h.__class__.__name__, 'Hardware')
        self.assertEqual(self.heavy_h.software_components, [])

        self.assertEqual(self.heavy_h.type, 'Heavy')
        self.assertEqual(self.power_h.type, 'Power')

    def test_install_heavy_h(self):
#        self.heavy_h.install('UU')
        self.heavy_h.software_components.append('UU')
        self.assertEqual(len(self.heavy_h.software_components), 1)
        self.assertEqual(self.heavy_h.software_components, ['UU'])

    def test_uninstall_heavy_h(self):
        self.heavy_h.software_components.append('UU')
        self.assertEqual(len(self.heavy_h.software_components), 1)
        self.heavy_h.uninstall('UU')
        self.assertEqual(len(self.heavy_h.software_components), 0)
        self.assertEqual(self.heavy_h.software_components, [])

    def test_install_power_h(self):
        #        self.heavy_h.install('UU')
        self.power_h.software_components.append('YY')
        self.assertEqual(len(self.power_h.software_components), 1)
        self.assertEqual(self.power_h.software_components, ['YY'])

    def test_uninstall_power_h(self):
        self.power_h.software_components.append('YY')
        self.assertEqual(len(self.power_h.software_components), 1)
        self.power_h.uninstall('YY')
        self.assertEqual(len(self.power_h.software_components), 0)
        self.assertEqual(self.power_h.software_components, [])

    def test_install_bad_raise_ex(self):
        self.hardware = Hardware("SSD", "Heavy", 100, 100)
        self.software_bad = Software("Win","Light",  100000, 100000)
        with self.assertRaises(Exception) as ex:
            self.hardware.install(self.software_bad)
        self.assertEqual(str(ex.exception), "Software cannot be installed")


if __name__ == "__main__":
    unittest.main()