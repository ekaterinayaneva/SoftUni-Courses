from project.software.software import Software


class Hardware:

    def __init__(self, name: str, type: str, capacity: int, memory: int):
        self.name = name
        self.type = type
        self.capacity = capacity
        self.memory = memory
        self.software_components = []

    def install(self, software: Software):
        occupied_memory = sum([s.memory_consumption for s in self.software_components])
        occupied_capacity = sum([s.capacity_consumption for s in self.software_components])
        if software.capacity_consumption + occupied_capacity > self.capacity \
                or software.memory_consumption + occupied_memory > self.memory:
            raise Exception("Software cannot be installed")
        self.software_components.append(software)

        # s = [s.name for s in self.name][0]
        # if self.capacity >= s.capacity_consumption and self.memory >= s.memory_consumption:
        #     self.software_components.append(software)
        #     return
        # return "Software cannot be installed"

    def uninstall(self, software: Software):
        self.software_components.remove(software)
