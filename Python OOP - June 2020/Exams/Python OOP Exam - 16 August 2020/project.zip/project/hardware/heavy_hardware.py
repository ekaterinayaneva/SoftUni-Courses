from project.hardware.hardware import Hardware


class  HeavyHardware(Hardware):
    def __init__(self, name:str, capacity:int, memory:int):
        Hardware.__init__(self, name, 'Heavy', capacity, memory)
     #   self.capacity *= 2
      #  self.memory *= 0.75
        self.capacity = int(self.capacity * 2)
        self.memory = int(self.memory * 0.75)

