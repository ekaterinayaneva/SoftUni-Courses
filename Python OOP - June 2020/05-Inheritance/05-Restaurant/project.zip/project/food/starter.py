#from inheritance_5.restaurant_5.project.food.food import Food
from project.food.food import Food


class Starter(Food):
    pass
